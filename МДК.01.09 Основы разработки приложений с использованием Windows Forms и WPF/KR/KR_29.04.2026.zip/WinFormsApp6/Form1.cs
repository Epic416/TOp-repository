using Newtonsoft.Json;

namespace WinFormsApp6
{
    public partial class Form1 : Form
    {
        private List<Contact> contacts = new List<Contact>();
        private BindingSource bs = new BindingSource();
        private const string FilePath = "C:\\Users\\User\\source\\repos\\WinFormsApp6\\WinFormsApp6\\contactaas.json";

        public Form1()
        {
            InitializeComponent();
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.ReadOnly = true;
            dataGridView1.AllowUserToAddRows = false;

            this.Load += Form1_Load;
            this.FormClosing += Form1_FormClosing;
            button1.Click += button1_Click;
            button2.Click += button2_Click;
            textBoxSearch.TextChanged += textBoxSearch_TextChanged;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (File.Exists(FilePath))
            {
                string json = File.ReadAllText(FilePath);
                contacts = JsonConvert.DeserializeObject<List<Contact>>(json) ?? new List<Contact>();
            }
            UpdateGrid();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            File.WriteAllText(FilePath, JsonConvert.SerializeObject(contacts, Formatting.Indented));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text) || string.IsNullOrWhiteSpace(textBox2.Text) || string.IsNullOrWhiteSpace(textBox3.Text) || string.IsNullOrWhiteSpace(textBox4.Text))
            {
                MessageBox.Show("Заполните поля", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            contacts.Add(new Contact
            {
                Name = textBox1.Text.Trim(),
                Surname = textBox2.Text.Trim(),
                Number = textBox3.Text.Trim(),
                Email = textBox4.Text.Trim()
            });

            UpdateGrid();
            textBox1.Clear(); textBox2.Clear(); textBox3.Clear(); textBox4.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0) return;

            var item = dataGridView1.SelectedRows[0].DataBoundItem as Contact;
            if (item != null)
            {
                contacts.Remove(item);
                UpdateGrid();
            }
        }

        private void textBoxSearch_TextChanged(object sender, EventArgs e) => UpdateGrid();

        private void UpdateGrid()
        {
            string search = textBoxSearch.Text.Trim().ToLower();
            var data = string.IsNullOrEmpty(search) ? contacts : contacts.Where(c =>
                (c.Name?.ToLower().Contains(search) ?? false) ||
                (c.Surname?.ToLower().Contains(search) ?? false) ||
                (c.Number?.Contains(search) ?? false) ||
                (c.Email?.ToLower().Contains(search) ?? false)
            ).ToList();

            bs.DataSource = null;
            bs.DataSource = data;
            dataGridView1.DataSource = bs;
        }
    }

    public class Contact
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Number { get; set; }
        public string Email { get; set; }
    }
}